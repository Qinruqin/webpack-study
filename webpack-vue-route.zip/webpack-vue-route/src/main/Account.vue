<template>
	<div>
		这是 Account 组件
		<router-link to='/account/login'>  登录 </router-link>
		<router-link to='/account/register'> 注册 </router-link>
		<router-view></router-view>
	</div>
</template>

<script>
	
</script>

<style lang="scss" scoped>
/* 普通style 只支持普通css样式，如果要启用scss或less，需要为style元素设置 lang 属性 */
	body {
		div{
			font-style: italic;
		}
	}
</style>