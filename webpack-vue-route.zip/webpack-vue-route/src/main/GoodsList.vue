<template>
	<div>
		这是 GoodsList 组件
	</div>
</template>

<script>
	
</script>

<style>
	
</style>