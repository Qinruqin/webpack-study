<template>
	<div>
		这是 Login 组件
	</div>
</template>

<script>
	
</script>

<style scoped>
/* 仅限当前组件使用以下样式，需要设置 scoped （是在.vue中都推荐使用） */
	div{
		color: red;
	}
</style>