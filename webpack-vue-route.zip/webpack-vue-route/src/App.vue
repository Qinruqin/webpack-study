<template>
	<div>
		<h3>这是 App 组件</h3>

		<router-link to='/account'>Account</router-link>
		<router-link to='/goodslist'>GoodsList</router-link>
		<router-view></router-view>
	</div>
</template>

<script>
	
</script>

<style>
	
</style>