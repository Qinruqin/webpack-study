// 这是Node中向外暴露成员的形式：
// module.exports = {

// }

//这是export 向外暴露成员的形式：
//使用该方式，main.js中只能这样使用import {title} from "./test.js";
//{按需导出}
export var title = '这是标题';
export var content = '这是内容';

//只能export default一次
export default {
   name:'zs',
   age:10
}
