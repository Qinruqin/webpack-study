// 这是js的入口文件
import Vue from "vue";

// import Vue from "../node_modules/vue/dist/vue.js";

// 1.导入login组件
import login from "./login.vue";
import info ,{title,content} from "./test.js";

console.log(info);
console.log(title+'----'+content);

var vm = new Vue({
	el:"#app",
	data:{
		msg:'123'
	},
	render:c => c(login)
})