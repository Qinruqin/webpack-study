<template>
	<div>
		<h3>这是login组件，通过vue文件导入的 --- {{msg}}</h3>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				msg:'hello'
			}
		},
		methods:{
			show(){
				console.log("调用了 login.vue 中的show方法")
			}
		}
	}
</script>

<style>
</style>