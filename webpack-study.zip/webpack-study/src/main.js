// 这是js的入口文件
// import xxx from xxx是ES6导入方式的写法	
import $ from 'jquery';
//webpack默认只能处理js类型的文件，无法处理其他非js类型的文件
//如果要处理其他非js类型的文件，需要安装第三方 loader 加载器
// 1.如果想要打包处理css文件，需要安装npm i style-loader css-loader -D
// 2.在webpack.config.js中新增一个配置节点:module对象，有个rules属性（数组，存放所有第三方文件的匹配和处理的规则）
import './css/index.css';
import './css/index.less';
import './css/index.scss';

//webpack处理第三方文件类型的过程:
// 1.发现该文件不是JS类型的文件时，就会到配置文件中,查找有没有对应的第三方loader的规则
// 2.如果找到对应规则，就会调用相应的loader规则处理这种文件类型
// 3.在处理规则时，是从右往左调用的
// 4.当最后一个处理后，会把结果直接打包合并，输出到bundle.js中

$(function(){
	$('li:odd').css('backgroundColor','lightblue');
	$('li:even').css('backgroundColor','yellow');
});
// 1、webpack能处理js文件的依赖关系
// 2、webpack能处理js兼容性问题，把高级的、浏览器不识别的语法转成低级的、浏览器能正常识别的语法

// 刚才运行的命令：webpack 要打包的文件路径 --output  打包好的文件路径 --mode development

// 使用webpack-dev-server这个工具，来实现自动打包编译的功能
// 1.运行 npm i webpack-dev-server -D 把这个工具安装到项目的本地开发依赖
// 2.安装完毕后，这个工具的用法，和webpack的用法完全一样
// 3.由于是在项目中安装，所以无法把它当做 脚本命令 ，在终端无法正常执行
// 4.注意：webpack-dev-server这个工具，如果想要正常运行，要求，在本地项目中，必须安装webpack
